
class relation:
    def __init__(self):
        self.chess_type = 0
        self.num_attack = 0
        self.num_guard = 0
        self.num_attacked = 0
        self.num_guarded = 0
        self.attack = [0, 0, 0, 0, 0, 0]
        self.attacked = [0, 0, 0, 0, 0, 0]
        self.guard = [0, 0, 0, 0, 0, 0]
        self.guarded = [0, 0, 0, 0, 0, 0]
